Pre-Requisites:

Step 1: To run C++ code on your machine you must have the C++ Compiler installed if not install it first(GNU Compiler / MinGW ). Step 2: After installation follow below steps select Start -> Computer -> System Properties -> Advanced System Settings -> Environment Variables -> System Variables -> PATH. Click “Edit” and at the end append the C++ Compiler path after semicolon;

To Run:

Method 1(Using Command Prompt) Step 1: open command prompt first. Step 2: Switch to the directory where you store the code file using the command(cd "directory path"). Step 3: Write command as g++ with C++ code file name i.e g++ filename.cpp to compile the code (eg:- g++ NumberToCurrencyConverter.cpp). Step 4: write commandas c++ with filename i.e c++ filename to run the code (eg:- g++ NumberToCurrencyConverter)

Method 2(using Code Block IDE)

Step 1: Download Code Block IDE if not installed on your machine. Step 2: Open Code Block IDE and create the project in to the repository folder with any name and create new c++ file into that project with tha name of NumberToCurrencyConverter.cpp and copy the code from the link code file and paste the code into the NumberToCurrencyConverter.cpp or You may import/open NumberToCurrencyConverter.cpp file from the github link of mine. Step 3: To execute the code press the build & Run button on the top menu to run the code and see the result on console. Step 4: Enter the input for the code execution and see the output on the console.
